x="demonstrates min pack"
def mainpackdemo():
    return "main package demonstration"