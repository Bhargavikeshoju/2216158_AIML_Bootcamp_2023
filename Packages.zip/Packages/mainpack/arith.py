import mainpack as mp
print (mp.x)
print(mp.mainpackdemo())
print("________")

import mainpack.subpack1 as ms1
print(ms1.sub1)
print(ms1.subpack1)
print("________")

from mainpack.subpack1 import addsub as sa
print(sa.addn(5,5))
print(sa.subn(10,5))

import mainpack.subpack2 as ms2
print(ms2.sub2)
print(ms2.subpack2)
print("________")

from mainpack.subpack2 import muldiv as md
print(md.muln(3,3))
print(md.divn(10,5))