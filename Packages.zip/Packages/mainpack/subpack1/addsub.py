def addn(x,y):
    return x+y
def subn(x,y):
    return x-y