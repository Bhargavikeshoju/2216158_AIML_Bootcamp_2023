#step1
import sqlite3

#step2 & 3
"Bootcamp2023.db"
conn=sqlite3.connect("Bootcamp2023.db")

'''
describe table_name-->mysql
pragma table_info(table_name)-->sqlite3
'''
#step4
query='''
        pragma table_info(participants1)
        '''
details=conn.execute(query)
print(details)
for i in details:
    print(i)
