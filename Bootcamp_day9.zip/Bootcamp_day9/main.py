#steps
'''
#1. importing the module
#2. create a database
#3. establish the connection with database
#4. creating a table in the database-participants-writing the query
#5. execute the query
'''
#step1
import sqlite3

#step2 & 3
"Bootcamp2023.db"
conn=sqlite3.connect("Bootcamp2023.db")

#step4
query='''create table participants1(G_id int primary key,name text not null,branch text not null,study text not null DEFAULT 'BTECH')'''

#step5
conn.execute(query)

#describe table_name