#step1
import sqlite3

#step2 & 3
"Bootcamp2023.db"
conn=sqlite3.connect("Bootcamp2023.db")
print(conn)

records=conn.execute("select *from participants1")
print(records)
for i in records:
    print(i)
conn.commit()
conn.close()