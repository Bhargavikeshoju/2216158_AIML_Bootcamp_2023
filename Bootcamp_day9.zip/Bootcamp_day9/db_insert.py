#step1
import sqlite3

#step2 & 3
"Bootcamp2023.db"
conn=sqlite3.connect("Bootcamp2023.db")
print(conn)
'''
insert into table_name values('','',........)
'''
conn.execute("insert into participants1 values(1,'Bhargavi','CSE','BTech','keshojubhargavi123@gmail.com')")
conn.execute("insert into participants1 values(2,'Pujitha','CSE','BTech','pujitha123@gmail.com')")
conn.execute("insert into participants1 values(3,'Abhigna','CSE','BTech','abhignaraj123@gmail.com')")
conn.execute("insert into participants1 values(4,'Maseera','CSE','BTech','maseera123@gmail.com')")
conn.execute("insert into participants1 values(5,'Ravi','ECE','BTech','ravi123@gmail.com')")
conn.execute("insert into participants1 values(6,'Hamsika','ECE','BTech','hamsika123@gmail.com')")
conn.execute("insert into participants1 values(7,'Saba','ECE','BTech','saba123@gmail.com')")
conn.execute("insert into participants1 values(8,'Deepika','ECE','BTech','deepika123@gmail.com')")

print(conn.total_changes)
records=conn.execute("select *from participants1")
print(records)
for i in records:
    print(i)
conn.commit()
conn.close()
