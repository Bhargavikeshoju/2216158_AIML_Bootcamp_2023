#step1
import sqlite3

#step2 & 3
"Bootcamp2023.db"
conn=sqlite3.connect("Bootcamp2023.db")
print(conn)

'''
drop table table_name
'''
conn.execute("drop table participants1")