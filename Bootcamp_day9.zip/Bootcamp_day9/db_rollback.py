#step1
import sqlite3

#step2 & 3
"Bootcamp2023.db"
conn=sqlite3.connect("Bootcamp2023.db")
print(conn)
conn.execute("delete from participants1 where branch='ECE'")
conn.execute("rollback")
print(conn.total_changes)
conn.commit()
conn.close()