#step1
import sqlite3

#step2 & 3
"Bootcamp2023.db"
conn=sqlite3.connect("Bootcamp2023.db")
print(conn)
'''
update the name in the table
update table_name set column_name='new value' where <<condition>>
'''
conn.execute("update participants1 set name='Keshoju Bhargavi' where G_id=1")
conn.commit()
conn.close()